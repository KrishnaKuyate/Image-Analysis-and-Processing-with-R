###########Discrete Fourier Transform (DFT) of the image as a magnitude / phase image pair.

install.packages("magick")
library(magick)

#Get Structure of magick package

#Read Image
image_read("Child_Cute.jpg")->Boy
Boy

image_fft(Boy)


